# RimArcho 日本語翻訳 — 開発者提出用

このZIPは、RimArcho v1.0.9 の元ソースに対して日本語対応の変更を適用できるように整理したものです。ソース全体や実行ファイルは含めていません。

## 中身

- `japanese-localization.patch` — GitHub開発者向けの変更差分（推奨）
- `changes/` — 差分と同じ内容のファイル一式。Gitを使わずに上書きする場合
- `README.md` — 英語での実装内容・適用方法
- `VALIDATION.md` — テスト内容と未検証の項目
- `PR_MESSAGE_EN.md` — GitHubに送る英語の文章例
- `LICENSE` — 元プロジェクトのMITライセンス

**パッチ適用と `changes/` のコピーは、どちらか片方だけ**でOKです。開発者にはGitHubのIssueやPull RequestでこのZIPを案内するか、パッチと英語説明を渡してください。

元ソースをそのままコピーしたものではなく、日本語翻訳に必要な変更に絞っています。過去のWindows用ビルドスクリプトや日本語版EXEは入れていません。

Windowsで表示確認できたのはこれまでのプレビュー版です。提出版の全機能テストと、ゲーム内Archo Monitorの動作確認は開発者側でも必要です。
