# Validation notes

**Reference:** Provided `RimArcho-master.zip` upstream source snapshot (v1.0.9), compared to the local Japanese v6 preview.

## Checks performed on this submission

- 3,762 unique standard JA locale keys and 81 auxiliary keys retained from v6, including all 3,711 ordinary and 81 auxiliary keys present in the shipped Chinese locale.
- The feature-based JSON regrouping preserves every original key/value pair. No conflicting translation values were found.
- All translation JSON files parse as UTF-8 JSON; Archo Monitor Japanese XML parses successfully.
- `git apply --check` and `git apply` passed on a fresh copy of the provided upstream snapshot; the result matches the included file overlay.
- `gofmt` reports no formatting changes for modified Go files.
- JavaScript parse test (`node --check`) passed for the modified `state.js`.
- Go locale tests: **PASSED** with Go 1.27.3 (`GOPROXY=off go test ./internal/l10ndata -count=1`).

## Still required before merge or release

- Full Go test suite (`go test ./...`), which may require external dependency downloads.
- Windows GUI build/run and language switching `auto` / `en` / `zh` / `ja` on this **consolidated submission**.
- RimWorld in-game Archo Monitor settings display with Japanese selected.
- Review of rare dynamic server/CLI error messages and UI overflow in long Japanese translations.

This is a source contribution, **not** an official or verified production build.
