package l10ndata

import (
	"fmt"
	"slices"
	"strings"
	"testing"
)

func TestJapaneseLocale(t *testing.T) {
	t.Setenv("ARCHO_LANG", "")
	if !slices.Contains(LanguageCodes(), "ja") {
		t.Fatal("Japanese is not available in UI language settings")
	}
	for _, input := range []string{"ja", "ja-JP", "JA_jp.UTF-8"} {
		if got := ResolveLang(input); got != "ja" {
			t.Errorf("ResolveLang(%q) = %q; want ja", input, got)
		}
	}
	ja := Locales["ja"]()
	if ja.Name != "ja" || ja.Text["language"] == "" || ja.Text["home"] == "" {
		t.Fatal("Japanese locale is missing essential interface strings")
	}
	if len(ja.Clashes) != 0 {
		t.Fatalf("Japanese locale has conflicting translations: %v", ja.Clashes)
	}
	if !strings.Contains(DefaultPinnedTags("ja"), "RimWorld") {
		t.Error("Japanese default tags are missing RimWorld")
	}
	for key := range Locales["zh"]().Text {
		if strings.TrimSpace(ja.Text[key]) == "" {
			t.Errorf("Japanese locale lacks existing translated key %q", key)
		}
	}
	for key := range Locales["zh"]().ExtraText {
		if strings.TrimSpace(ja.ExtraText[key]) == "" {
			t.Errorf("Japanese locale lacks existing auxiliary key %q", key)
		}
	}
}

func TestJapaneseRepresentativeText(t *testing.T) {
	translated := Locales["ja"]().Text
	for _, key := range []string{
		"before you start", "can it load?", "the DDS encoder",
		"unknown subscription source", "account operations are closed",
		"RimArcho was uninstalled; account operations are disabled",
		"the Workshop page is fetched in a moment", "shared logs (up to %s)",
	} {
		if translated[key] == "" || translated[key] == key {
			t.Errorf("missing Japanese translation for %q", key)
		}
	}
}

func TestJapaneseFormattedDiagnostics(t *testing.T) {
	translations := Locales["ja"]().Text
	cases := []struct {
		key      string
		args     []any
		expected []string
	}{
		{"saving the %d mods read from %s…", []any{7, "Mods/"}, []string{"Mods/", "7"}},
		{"%d parts of %s build on definitions no enabled mod provides; a dependency may be missing", []any{8, "ExampleMod"}, []string{"ExampleMod", "8"}},
		{"%d parts of %s may be missing a dependency", []any{2, "ExampleMod"}, []string{"ExampleMod", "2"}},
		{"%d patches of %s do not take effect", []any{3, "ExampleMod"}, []string{"ExampleMod", "3"}},
		{"%d patches of %s do not take effect: %s, which they target, is not enabled", []any{4, "ExampleMod", "TargetMod"}, []string{"ExampleMod", "4", "TargetMod"}},
		{"%d uses of %s", []any{12, "Building"}, []string{"Building", "12"}},
	}
	for _, test := range cases {
		value, ok := translations[test.key]
		if !ok {
			t.Errorf("translation missing: %q", test.key)
			continue
		}
		out := fmt.Sprintf(value, test.args...)
		if strings.Contains(out, "%!") {
			t.Errorf("invalid format %q: %s", test.key, out)
		}
		for _, expected := range test.expected {
			if !strings.Contains(out, expected) {
				t.Errorf("translation for %q lost %q: %s", test.key, expected, out)
			}
		}
	}
}
