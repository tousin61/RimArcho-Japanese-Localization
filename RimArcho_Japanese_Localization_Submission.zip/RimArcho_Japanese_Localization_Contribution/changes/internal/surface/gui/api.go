package gui

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net/url"
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"github.com/ToumanLin/RimArcho/internal/app"
	"github.com/ToumanLin/RimArcho/internal/bbcode"
	"github.com/ToumanLin/RimArcho/internal/buildinfo"
	"github.com/ToumanLin/RimArcho/internal/cmds"
	"github.com/ToumanLin/RimArcho/internal/modchanges"
	"github.com/ToumanLin/RimArcho/internal/perftrace"
	"github.com/ToumanLin/RimArcho/internal/store"
	"github.com/ToumanLin/RimArcho/internal/subscribe"
	"github.com/ToumanLin/RimArcho/internal/view"
)

// API is the service the page calls (16 §1, §3): every method returns view models from
// internal/view, or runs a view verb. No business rule lives here.
//
// The app is not safe for concurrent use and Wails calls methods concurrently, so each
// method locks its App. Slow texture/log reads use separate sessions; descriptions use
// a snapshot of the index. Only snapshotting settings/results needs the shared mu.
type API struct {
	mu              sync.Mutex
	filesMu         sync.RWMutex // scans and file jobs; never acquired by page reads/edits
	a               *app.App
	emit            func(name string, data any) // Wails events; nil in tests
	open            func(url string) error      // the system browser
	openDir         func(dir string) error      // the file manager (nil: the system's)
	lib             *app.Library                // Mod library, as of libAt
	libAt           string
	libGate         sync.Mutex // coalesces full inventory builds, never acquired by edits
	problemLookup   problemLookup
	search          fileSearch // Search files (filesearch.go)
	subRead         subscriptionReader
	copyRead        inventoryReader
	libRead         logReader
	plansRead       logReader
	workspaceReader logReader
	indexRead       logReader
	detailRead      logReader
	board           *view.Board
	boardAt         string
	needs           *view.Needs
	needsAt         string // the database state the needs were built at
	content         view.ContentCache
	busy            map[string]bool // scan, analyze, pack
	workspace       *workspaceSnapshot
	needsCache      map[string]*needsSnapshot
	needsJobs       sync.WaitGroup
	needsRefreshing bool
	needsClosed     bool
	needsWanted     bool
	needsSequence   uint64
	listEdits       uint64
	// building is the pack this window's build child is making ("" none).
	building  string
	buildRead buildPageReader
	live      view.LiveTracker  // the running game's log (06 §6)
	liveSt    *app.LoadoutState // the loadout Live last followed the game with (liveStateLocked)
	logPath   string            // the log page's Player.log and its clusters' first lines
	logLinks  map[string]string
	x         exchange // import and export (exchange.go)
	// removedRule is the rule the editor removed last, for its undo (rules.go).
	removedRule *store.UserRule
	free        releaser // returns memory to the OS after heavy work (memory.go)
	// bgs are the environment bgsEnv's backgrounds; bgPick the image rotation chose for
	// this window (background.go)
	bgs    []app.Background
	bgsEnv string
	bgPick string
	bgRead backgroundReader
	// Exe runs the scan, analysis and pack build children; "" is this executable (the
	// development harness points it at archo.exe).
	Exe string

	environment     environmentWorker
	monitorOnce     sync.Once
	autoOnce        sync.Once
	maintenanceOnce sync.Once
	autoWG          sync.WaitGroup
	quit            func()        // closes the window (nil in the harness and in tests)
	windowTheme     func(bool)    // synchronises the native frame with the resolved page scheme
	memTarget       *memoryTarget // WebView2's memory target (winmem_policy.go); nil off Windows and in tests
	// tasks is the Background tasks record and its lanes (tasks.go, 16 §2.16)
	tasks        *app.Tasks
	taskEv       taskEvents
	creditID     string
	creditCancel context.CancelFunc
	creditWG     sync.WaitGroup
	creditClosed bool
	// PackRunner builds a pack in place of the child process (tests).
	PackRunner func(name string) error
	// TexRunner runs `archo textures optimize` in place of the child process (tests).
	TexRunner     func(args []string, progress func(string)) ([]string, error)
	texLast       TextureEvent // the running conversion's last progress
	texCancel     context.CancelFunc
	texMeasure    textureMeasurement
	logRead       logReader
	texRead       logReader
	feedback      feedbackState
	costMeasure   loadCostMeasurement
	accountMu     sync.Mutex
	accountActive bool
	accountClosed bool
	ll            *subscribe.LoversLab
	llFiles       map[string]loverDownload

	uninstall      uninstallState
	saves          savesState // the Saves page's reader and listing (saves.go)
	uninstallSizes app.UninstallSizeCache
	uninstallRead  logReader

	branchCtx    context.Context
	branchCancel context.CancelFunc
	// ScanRunner scans an environment in place of the child process (tests).
	ScanRunner func(env string) (string, error)

	subRevision atomic.Uint64 // completed tasks may change files without a DB write
	command     commandWorker
}

func newAPI(a *app.App) *API {
	ctx, cancel := context.WithCancel(context.Background())
	s := &API{a: a, open: openURL, busy: map[string]bool{}, branchCtx: ctx, branchCancel: cancel}
	a.LaunchWait = func(text string) { s.send("launch-wait", map[string]any{"text": view.T(text)}) }
	s.startTasks()
	s.startCreditLocked()
	return s
}

func (s *API) send(name string, data any) {
	if s.emit != nil {
		s.emit(name, data)
	}
}

// ---- start ----

// processStart is when this process began (close enough: package initialisation).
var processStart = time.Now()

// Ready is called once the launch page or first-run guide has drawn; it logs the
// start-up time to <data>/logs/gui.log.
func (s *API) Ready() {
	defer perftrace.Span("Ready")()
	s.startAutomatic()
	s.startMaintenance()
	s.prepareBackgrounds(false) // menu extraction starts after the first draw (16 §3.1)
	s.monitorOnce.Do(s.checkMonitor)
	ms := time.Since(processStart).Milliseconds()
	dir := filepath.Join(s.a.Home, "logs")
	if os.MkdirAll(dir, 0o755) != nil {
		return
	}
	f, err := os.OpenFile(filepath.Join(dir, "gui.log"), os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0o644)
	if err != nil {
		return
	}
	defer f.Close()
	fmt.Fprintf(f, "%s ready %d ms (%s)\n", time.Now().Format(time.RFC3339), ms, buildinfo.String())
}

// checkMonitor installs or updates Archo Monitor in a child process once per window (19 §6)
// and, when that changed something, refreshes the page the way a scan does.
func (s *API) checkMonitor() {
	home, env, exe := s.a.Home, s.a.EnvName, s.Exe
	go func() {
		var out string
		var err error
		if exe != "" {
			out, err = app.ChildMonitorExe(exe, home, env)
		} else {
			out, err = app.ChildMonitor(home, env)
		}
		if err != nil || !monitorChanged(out) {
			return
		}
		s.mu.Lock()
		s.board, s.needs = nil, nil
		s.mu.Unlock()
		s.send("scan", map[string]any{"ok": true, "text": view.T("Archo Monitor is ready")})
	}()
}

// monitorChanged reports whether `monitor install` changed something the page shows: it
// copied or replaced the Monitor, registered or merged its source, or edited a plan
// (cmds.MonitorLines). The lines naming the plans it left alone ("plan:X: not added: no
// Harmony") and the deferred replacement while a game runs come on every start and change
// nothing; until 1.0.6 they dropped the window's board each time (VM round 1.0.6, B2).
func monitorChanged(out string) bool {
	return monitorChangeRe.MatchString(out)
}

var monitorChangeRe = regexp.MustCompile(`\binstalled \S+ to |\breplaced .*\(a development build changed\)|\bregistered src:|\bmerged \d+ older monitor|\(one undoable edit\)`)

// Start is what the page needs once: the language, its text table, the commands.
type Start struct {
	Lang        string            `json:"lang"`
	Accent      string            `json:"accent"`
	Theme       string            `json:"theme"`
	ArchoMotion string            `json:"archoMotion"`
	Motion      string            `json:"motion"`
	Text        map[string]string `json:"text"`
	ExtraText   map[string]string `json:"extraText,omitempty"`
	Commands    []view.Command    `json:"commands"`
	Version     string            `json:"version"`
	// Ops is the op table both pages' menus, hint lines and keys come from (16 §8.5).
	Ops []view.Op `json:"ops"`
}

// Init returns the page's start data.
func (s *API) Init() *Start {
	defer perftrace.Span("Init")()
	s.mu.Lock()
	defer s.mu.Unlock()
	return &Start{Lang: view.Lang(), Accent: cmds.Setting(s.a, "ui.accent"), Theme: cmds.Setting(s.a, "ui.theme"), ArchoMotion: cmds.Setting(s.a, "ui.archo.motion"), Motion: cmds.Setting(s.a, "ui.motion"), Text: view.Table(), ExtraText: view.ExtraText(), Commands: view.Commands, Version: buildinfo.String(), Ops: view.OpTable()}
}

// ---- the board ----

// Board is the three columns with what surrounds them.
type Board struct {
	Problems *view.ListProblems `json:"problems,omitempty"`
	*view.Board
	Status map[string]int `json:"status"` // row icons (16 §7)
	// Reasons are the items behind each row icon, for its hover / pinned popover (16 §4.2).
	Reasons   map[string][]view.Reason `json:"reasons,omitempty"`
	Needs     int                      `json:"needs"` // the top bar's number
	Stamp     string                   `json:"stamp"` // the database state: the page reloads when it changes
	Envs      []string                 `json:"envs"`
	Error     string                   `json:"error,omitempty"`
	Scanning  bool                     `json:"scanning"`
	Analyzing bool                     `json:"analyzing"`
	Never     bool                     `json:"neverScanned"`
}

// Board builds the columns (16 §2.5) and the counts from the workspace.
func (s *API) Board() *Board {
	s.mu.Lock()
	defer s.mu.Unlock()
	defer s.free.soon()
	return s.boardLocked()
}

func (s *API) boardLocked() *Board {
	defer perftrace.Span("Board-build")()
	key, err := s.a.LoadoutKey()
	b := s.board
	if err != nil || b == nil || key != s.boardAt {
		b, err = view.BuildBoard(s.a)
		if err == nil {
			s.boardAt, _ = s.a.LoadoutKey()
		}
	}
	s.board = b
	out := &Board{Board: b, Stamp: s.a.Store.ChangeKey(), Scanning: s.busy["scan"], Analyzing: s.busy["analyze"]}
	if err != nil {
		out.Error = view.Humanize(nil, err.Error())
		return out
	}
	envs, err := s.a.Store.Envs()
	if err != nil {
		out.Error = err.Error()
		return out
	}
	for _, e := range envs {
		out.Envs = append(out.Envs, e.Name)
	}
	if e, err := s.a.Env(); err == nil {
		sc, _, _ := s.a.LastScan(e.ID)
		out.Never = sc == nil
	}
	n := s.needsLocked()
	if n.Error != "" {
		out.Error = n.Error
		return out
	}
	out.Problems = s.problemsNowLocked(n)
	out.Status, out.Reasons, out.Needs = n.Status, n.Reasons, n.Count
	return out
}

// Stamp is the database state; the page asks on focus and reloads when it changed (G8).
// PackList is the environment's packs, how many belong to other environments, and the
// builds running or cut short.
type PackList struct {
	Rows       []view.PackRow       `json:"rows"`
	Others     int                  `json:"others"`
	Unfinished []view.UnfinishedRow `json:"unfinished"`
	Building   string               `json:"building,omitempty"` // the build this window started
}

// Packs lists the current environment's packs (10).
func (s *API) Packs() (*PackList, error) {
	r, err := s.detachedReader()
	if err != nil {
		return nil, err
	}
	defer r.Close()
	defer s.free.soon()
	rows, others, err := view.PackRows(r)
	if err != nil {
		return nil, err
	}
	un, err := view.UnfinishedRows(r)
	s.mu.Lock()
	defer s.mu.Unlock()
	return &PackList{Rows: rows, Others: others, Unfinished: un, Building: s.building}, err
}

// PackNameCheck says what is wrong with a new pack's name ("" when it can be used).
func (s *API) PackNameCheck(name string) string {
	s.mu.Lock()
	defer s.mu.Unlock()
	name = strings.TrimSpace(name)
	if name == "" {
		return view.T("give the pack a name")
	}
	if app.CheckPackName(name) != nil {
		return view.T("letters, digits, spaces and . _ - only (up to 64)")
	}
	if _, err := s.a.ReadPack(name); err == nil {
		return view.T("a pack of this name exists")
	}
	return ""
}

// PackDryRun is preview the file list without writing to disk: the text of archo pack build --dry-run (nothing is written).
func (s *API) PackDryRun(name string, tex int) []string {
	r, err := s.detachedReader()
	if err != nil {
		return []string{err.Error()}
	}
	defer r.Close()
	argv := append([]string{"pack", "build", strings.TrimSpace(name), "--dry-run"}, app.PackBuildArgs(view.PackTextureOptions(tex))...)
	text, _ := cmds.Execute(r, argv)
	st, _ := r.Loadout()
	var out []string
	for _, l := range strings.Split(strings.TrimRight(text, "\n"), "\n") {
		if strings.HasPrefix(l, "usage:") {
			break // a refused build ends with the command's usage: not for the page
		}
		out = append(out, view.Humanize(st, l))
	}
	for len(out) > 0 && strings.TrimSpace(out[len(out)-1]) == "" {
		out = out[:len(out)-1]
	}
	return out
}

// Pack is one pack's page (16 §2.7).
func (s *API) Pack(name string) (*view.PackPage, error) {
	r, err := s.detachedReader()
	if err != nil {
		return nil, err
	}
	defer r.Close()
	defer s.free.soon()
	return view.BuildPackPage(r, name)
}

// PackExport writes a pack to a file the player picks (pack export): the save dialog in
// the window; file is the typed path where there is none. "" when it was cancelled. With
// list it writes only the pack's list, as a RimArcho list.
func (s *API) PackExport(name, file string, list bool) (string, error) {
	ext := ".archopack"
	if list {
		ext = ".archolist.json"
	}
	if file == "" {
		if s.x.native == nil {
			return "", errors.New(view.T("no file dialog here; use the desktop window"))
		}
		f, err := s.x.native.saveFile(view.T("export the pack"), name+ext, [][2]string{{"*" + ext, "*" + ext}, {"All files (*.*)", "*.*"}})
		if err != nil || f == "" {
			return "", err
		}
		file = f
	}
	r, err := s.detachedReader()
	if err != nil {
		return "", err
	}
	defer r.Close()
	n, err := r.ExportPack(name, file, list)
	if err != nil {
		return "", err
	}
	if list {
		return view.Tf("exported the list of pack %s to %s", name, file), nil
	}
	return view.Tf("exported pack %s to %s (%s)", name, file, view.SizeText(n)), nil
}

// PackBuild starts building the pack in an `archo pack build` child process and returns at
// once: the copy takes minutes and holds nothing here, so every page keeps working, and it
// goes on when the window closes. "pack" events carry the progress (view.PackProgress) and
// the end. One build at a time.
func (s *API) PackBuild(name string, tex int) (string, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if err := app.CheckPackName(name); err != nil {
		return "", err
	}
	if s.busy["pack"] {
		return "", errors.New(view.T("another pack is being created; wait for it to finish"))
	}
	if un, err := s.a.UnfinishedPacks(); err == nil {
		for _, u := range un {
			if u.Running {
				return "", errors.New(view.T("another pack is being created; wait for it to finish"))
			}
		}
	}
	if _, err := s.a.ReadPack(name); err == nil {
		return "", fmt.Errorf(view.T("pack %q exists; remove it first or pick another name"), name)
	}
	s.busy["pack"], s.building = true, name
	tmp := filepath.Join(s.a.PacksDir(), name+app.TmpSuffix)
	run := s.PackRunner
	if run == nil {
		home, env, exe, plan := s.a.Home, s.a.EnvName, s.Exe, s.a.OpenPlanName()
		log := filepath.Join(home, "logs", "pack-build.log")
		extra := app.PackBuildArgs(view.PackTextureOptions(tex))
		run = func(name string) error {
			if exe != "" {
				return app.ChildPackBuildExe(exe, home, env, plan, name, log, extra...)
			}
			return app.ChildPackBuild(home, env, plan, name, log, extra...)
		}
	}
	task := s.beginSelf(view.TaskPack, name, func() error { _, err := s.PackStop(name); return err })
	s.tasks.Update(task, func(t *app.Task) { t.Target, t.Detached = name, true })
	go s.watchBuild(task, name, tmp, run)
	return view.Tf("create pack %s: it goes on in the background; you can use the other pages, or close the window", name), nil
}

// watchBuild runs the build and passes its progress file on as events until it ends.
func (s *API) watchBuild(task, name, tmp string, run func(string) error) {
	done := make(chan error, 1)
	go func() { done <- run(name) }()
	t := time.NewTicker(300 * time.Millisecond)
	defer t.Stop()
	var last view.PackProgress
	for {
		select {
		case err := <-done:
			s.mu.Lock()
			s.busy["pack"], s.building = false, ""
			s.mu.Unlock()
			ev := view.PackProgress{Name: name, Done: true, Ok: err == nil, Step: 5, Frac: 1, Text: view.Tf("created pack %s", name)}
			if err != nil {
				ev.Step, ev.Frac, ev.Text = last.Step, last.Frac, ""
				lines := strings.Split(view.Humanize(nil, err.Error()), "\n")
				for i, l := range lines {
					lines[i] = view.T(strings.TrimPrefix(strings.TrimSpace(l), "error: "))
				}
				reason := strings.Join(lines, "\n")
				ev.Error = failedText(view.TaskPack, name, reason)
				s.tasks.Update(task, func(t *app.Task) { t.Step = last.Step })
				end := app.TaskFailed
				if s.tasks.StopAsked(task) {
					end = app.TaskStopped
				}
				s.tasks.Finish(task, end, reason)
			} else {
				s.tasks.Update(task, func(t *app.Task) { t.Step = 5 })
				s.endSelf(task, nil, ev.Text)
			}
			s.send("pack", ev)
			return
		case <-t.C:
			if p := app.ReadBuildProgress(tmp); p != nil {
				if pp := view.ProgressOf(p); pp != last {
					last = pp
					s.tasks.Update(task, func(t *app.Task) { t.Step, t.Frac, t.Phase = pp.Step, pp.Frac, pp.Text })
					s.send("pack", pp)
				}
			}
		}
	}
}

// PackStop asks a running build to stop (it removes what it copied).
func (s *API) PackStop(name string) (string, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if err := s.a.StopBuild(name); err != nil {
		return "", err
	}
	return view.Tf("asked %s to stop", name), nil
}

// PackRemoveUnfinished deletes what a build cut short copied (its folder in the packs
// folder, nothing else).
func (s *API) PackRemoveUnfinished(name string) (string, error) {
	s.mu.Lock()
	dir, err := s.a.UnfinishedDir(name)
	s.mu.Unlock()
	if err != nil {
		return "", err
	}
	defer s.subRevision.Add(1)
	if err := os.RemoveAll(dir); err != nil { // off the lock: gigabytes take a while
		return "", err
	}
	return view.Tf("deleted the unfinished pack %s", name), nil
}

// PackLaunch plays a pack. move: the player agreed to move the folders in the way into the
// lock library first (Outcome.Moves, 10 §3).
func (s *API) PackLaunch(name string, move bool) (*view.Outcome, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	return view.LaunchPack(s.a, name, move), nil
}

// PackRemove moves a pack to the recycle bin.
func (s *API) PackRemove(name string) (string, error) {
	defer s.subRevision.Add(1)
	s.mu.Lock()
	defer s.mu.Unlock()
	if _, err := s.a.RemovePack(name, false); err != nil {
		return "", err
	}
	return view.Tf("pack %s is in the recycle bin", name), nil
}

// Directories checks paths on disk even when no database row changed.
func (s *API) Directories() ([]app.ManagedDirectory, error) {
	defer perftrace.Span("Directories")()
	s.mu.Lock()
	defer s.mu.Unlock()
	dirs, err := s.a.ManagedDirectories()
	for i := range dirs {
		dirs[i].Label = view.DirectoryLabel(dirs[i])
	}
	return dirs, err
}

// Settings is the settings page (16 §2.14).
func (s *API) Settings() []view.SettingGroup {
	r, err := s.detachedReader()
	if err != nil {
		return nil
	}
	defer r.Close()
	defer s.free.soon()
	return view.SettingsPage(r, nil)
}

// Environment is the environment page: the environments, the current one's folders and
// launch.
func (s *API) Environment() *view.EnvPage {
	r, err := s.detachedReader()
	if err != nil {
		return &view.EnvPage{}
	}
	defer r.Close()
	defer s.free.soon()
	// This view needs only the environment's settings, not every installed Mod.
	var st *app.LoadoutState
	if e, err := r.Env(); err == nil {
		st = &app.LoadoutState{Ix: &app.Index{Env: e}}
	}
	return view.BuildEnvPage(r, st)
}

// ToolInstallOffer reads download details only after an explicit installation request.
func (s *API) ToolInstallOffer(name string) (*app.SteamCMDOffer, error) {
	a, err := s.detachedReader()
	if err != nil {
		return nil, err
	}
	defer a.Close()
	return a.OfferDep(name)
}

// ApplySetting runs one of the settings page's commands, with value in place of {}.
func (s *API) ApplySetting(argv []string, value string) ([]string, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if err := view.SettingCommand(argv); err != nil {
		return nil, err
	}
	run := make([]string, len(argv))
	for i, x := range argv {
		if x == "{}" {
			x = value
		}
		run[i] = x
	}
	if kind := view.SettingTask(run); kind != "" {
		t := s.queueSettingTaskLocked(kind, run, "")
		return []string{settingQueued(t)}, nil
	}
	text, code := cmds.Execute(s.a, run)
	s.board, s.needs = nil, nil
	if len(run) == 4 && run[0] == "config" && run[2] == "ui.lang" && code == cmds.ExitOK {
		view.SetLang(run[3])
	}
	lines := strings.Split(strings.TrimRight(text, "\n"), "\n")
	if code != cmds.ExitOK {
		return nil, fmt.Errorf("%s", strings.Join(lines, " "))
	}
	return lines, nil
}

// History is the history area (16 §2.5): unsaved steps around now, then the versions.
func (s *API) History() ([]view.HistItem, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.board == nil || s.board.St == nil {
		return nil, nil
	}
	return view.HistoryItems(s.a, s.board.St)
}

// HistoryGo moves through the unsaved steps (n > 0 undoes n, n < 0 redoes -n) or, with
// version > 0, loads that version into the list (loadout checkout).
func (s *API) HistoryGo(steps, version int) (*view.Result, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if version > 0 {
		r, _, err := s.a.Checkout(fmt.Sprintf("v%d", version))
		if err != nil {
			return nil, err
		}
		if r.Before.Equal(r.State.List) {
			return &view.Result{Text: view.T("no changes")}, nil
		}
		return &view.Result{Text: view.Tf("back at v%d (unsaved)", version), Undo: true}, nil
	}
	r, err := s.a.StepTo(steps)
	if err != nil {
		return nil, err
	}
	return &view.Result{Text: view.Tf("%d changes", len(r.Changes))}, nil
}

// Live reports the running game and the errors its log gained (16 §2.1); the page asks
// every two seconds.
func (s *API) Live() (*view.Live, error) {
	defer perftrace.Span("Live")()
	s.mu.Lock()
	defer s.mu.Unlock()
	st := s.liveStateLocked()
	if st == nil {
		return &view.Live{}, nil
	}
	return s.live.Update(s.a, st)
}

// liveStateLocked is the loadout Live follows the game with: the board's, else the last one
// it used while that is still the current environment's. Invalidations drop the board until
// the page reads the workspace again; the running game must not vanish meanwhile (a poll
// then would also take the gap for the game's exit). VM round 1.0.6, B2.
func (s *API) liveStateLocked() *app.LoadoutState {
	if s.board != nil && s.board.St != nil {
		s.liveSt = s.board.St
		return s.liveSt
	}
	if s.liveSt == nil {
		return nil
	}
	if e, err := s.a.Env(); err != nil || e == nil || e.ID != s.liveSt.Ix.Env.ID {
		s.liveSt = nil
	}
	return s.liveSt
}

func (s *API) Stamp() string {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.a.Store.ChangeKey()
}

// Filter returns the indexes of a column's rows that match the query (16 §3.7), and how
// many rows match in each column (for "other lists: …", 16 §3.7).
func (s *API) Filter(col int, query string) (*Filtered, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.board == nil || s.board.St == nil || col < 0 || col > 2 {
		return &Filtered{}, nil
	}
	q := view.ParseQuery(query)
	f := view.MatchFacts{Status: s.needsLocked().Status}
	if q.NeedsContent() {
		c, err := s.content.Get(s.a, s.board.St)
		if err != nil {
			return nil, err
		}
		f.Content = c
	}
	out := &Filtered{}
	var tags []string
	for k := range s.board.Cols {
		for i := range s.board.Cols[k] {
			tags = append(tags, s.board.Cols[k][i].Tags...)
		}
	}
	out.Complete = view.CompleteQuery(query, tags)
	for k := range s.board.Cols {
		ix := q.Filter(s.board.Cols[k], f)
		out.Counts[k] = len(ix)
		if k == col {
			out.Rows = ix
		}
	}
	return out, nil
}

// Filtered is the result of a column search.
type Filtered struct {
	Rows   []int  `json:"rows"`
	Counts [3]int `json:"counts"`
	// Complete is the grey text after the query that tab accepts (16 §3.7).
	Complete string `json:"complete,omitempty"`
}

// ---- the detail ----

// Detail is one mod's detail (16 §4.1), in the order the page shows it.
type Detail struct {
	ID         string      `json:"id"`
	Name       string      `json:"name"`
	Authors    string      `json:"authors,omitempty"`
	Kind       string      `json:"kind"`
	Header     []string    `json:"header"`
	Status     int         `json:"status"`
	StatusText string      `json:"statusText"`
	Facts      []view.Fact `json:"facts"`
	// Fields is the detail's one field list (16 §4.1): Archo ID, package, location, Workshop,
	// tags, languages, dependencies, conflicts.
	Fields      []view.Field   `json:"fields"`
	Deps        []view.Dep     `json:"deps"`
	Show        string         `json:"show"`
	Note        string         `json:"note,omitempty"`
	State       string         `json:"state,omitempty"` // the Workshop page's state
	About       []bbcode.Block `json:"about"`
	Workshop    []bbcode.Block `json:"workshop"`
	History     string         `json:"history,omitempty"`
	Missing     bool           `json:"missing,omitempty"`
	CanSeparate bool           `json:"canSeparate,omitempty"`
	URL         string         `json:"url,omitempty"` // the Workshop page
	Pos         int            `json:"pos,omitempty"`
	Version     *view.Reason   `json:"version,omitempty"`
}

// Detail returns the detail of an instance; fetch allows the network for the Workshop
// page (the page asks again after the cursor rested, 16 §4.3 item 3), refresh ignores the
// cache.
func (s *API) Detail(id string, staged, fetch, refresh bool) (*Detail, error) {
	defer perftrace.Span("Detail")()
	// Cursor reads retain their own caches. Network fetches get a short-lived
	// session so an earlier fetch cannot delay the next cursor's cached detail.
	var r *app.App
	var err error
	if fetch || refresh {
		s.mu.Lock()
		r, err = s.readInventorySession()
		s.mu.Unlock()
		if err == nil {
			defer r.Close()
		}
	} else {
		w := &s.detailRead
		w.mu.Lock()
		defer w.mu.Unlock()
		defer s.retainReader(w)
		s.mu.Lock()
		if w.a == nil {
			w.a, err = s.readInventorySession()
		} else {
			s.refreshInventorySession(w.a)
		}
		r = w.a
		s.mu.Unlock()
	}
	if err != nil {
		return nil, err
	}
	st, _ := r.Loadout()
	if st == nil {
		return nil, errors.New("no list")
	}
	mod := st.Ix.ByID[id]
	if mod == nil {
		return nil, fmt.Errorf(view.T("no mod %s"), id)
	}
	n, _ := readNeeds(r, false)
	pos := st.Position(id)
	item := view.ModItem(st, mod)

	data := view.LoadDetail(r, st.Ix, mod, fetch, refresh) // off the lock: may use the network
	d := &Detail{ID: id, Name: mod.DisplayName(), Authors: strings.TrimSpace(mod.Authors), Kind: view.SourceKind(mod), Pos: pos,
		Header: view.HeaderFacts(mod, pos, staged), Facts: view.Facts(mod, data), Deps: view.Deps(r, st, data), Fields: view.ModFields(r, st, mod, data),
		Show: data.Desc.Show, Note: view.DescNote(data), State: data.Desc.WorkshopState,
		About: data.About, Workshop: data.Workshop, History: view.HistoryLine(data.Events), CanSeparate: st.Ix.CanSeparate(mod)}
	d.Version = data.Version
	d.Status = view.RowStatus(&item, n.Status)
	switch d.Status {
	case view.StatusNone:
		d.StatusText = view.T("no problems found")
	case view.StatusUnloadable:
		d.StatusText = view.UnloadableWhy(st, mod)
	default:
		d.StatusText = view.T("needs attention")
	}
	if ws := mod.WorkshopID(); view.IsNumber(ws) {
		d.URL = view.WorkshopURL(ws)
	}
	return d, nil
}

// Sections are the full detail's sub-sections (16 §4.2), #refs replaced by names.
func (s *API) Sections(id string) ([]view.Section, error) {
	r, err := s.detachedReader()
	if err != nil {
		return nil, err
	}
	defer r.Close()
	defer s.free.soon()
	st, _ := r.Loadout()
	if st == nil || st.Ix.ByID[id] == nil {
		return nil, fmt.Errorf(view.T("no mod %s"), id)
	}
	secs := view.Sections(r, st.Ix, st.Ix.ByID[id])
	for i := range secs {
		for j, l := range secs[i].Lines {
			secs[i].Lines[j] = view.Humanize(st, l)
		}
	}
	return secs, nil
}

// Commands need the loadout, not thousands of rendered rows and problem summaries.
func (s *API) boardState() *app.LoadoutState {
	st, _ := s.a.Loadout()
	return st
}

// ---- verbs (16 §3.5) ----

func (s *API) object(ids, refs []string) view.Object {
	st := s.boardState()
	o := view.Object{IDs: ids, Refs: refs}
	if st != nil {
		if len(o.Refs) == 0 {
			o = view.ObjectOf(st, ids)
		} else {
			o.What = view.Named(st, ids)
			if len(ids) == 0 && len(refs) == 1 {
				o.What = strings.TrimPrefix(refs[0], "pkg:")
			}
		}
	}
	return o
}

func (s *API) after(r *view.Result, err error) (*view.Result, error) {
	s.board = nil
	if err != nil {
		return nil, errors.New(view.Humanize(s.boardState(), err.Error()))
	}
	s.listEdits++
	if r != nil {
		r.Problems = s.editProblemsLocked()
	}
	return r, nil
}

// Toggle is space: enable, disable, or put back (by the column the object is in).
func (s *API) Toggle(col int, ids, refs []string) (*view.Result, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.after(view.Toggle(s.a, view.Column(col), s.object(ids, refs)))
}

// Stage is t: stage, or put back from staging.
func (s *API) Stage(col int, ids []string) (*view.Result, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.after(view.Stage(s.a, view.Column(col), s.object(ids, nil)))
}

// Unstage takes mods out of staging (a drop on Disabled).
func (s *API) Unstage(ids []string) (*view.Result, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.after(view.Unstage(s.a, s.object(ids, nil)))
}

// MoveBy is J / K.
func (s *API) MoveBy(ids []string, d int) (*view.Result, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.after(view.MoveBy(s.a, s.object(ids, nil), d))
}

// Place puts the mods at a 1-based place of the list without them (m, or a drop).
func (s *API) Place(col int, ids []string, at int) (*view.Result, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.after(view.Place(s.a, view.Column(col), s.object(ids, nil), at))
}

// PosOptions are the position input's choices (16 §3.6).
func (s *API) PosOptions(ids []string, text string, before bool) ([]view.PosOpt, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	st := s.boardState()
	if st == nil {
		return nil, errors.New("no list")
	}
	return view.PosOptions(s.a, st, ids, text, before), nil
}

func (s *API) text(t string, err error) (string, error) {
	s.board = nil
	if err != nil {
		return "", errors.New(view.Humanize(s.boardState(), err.Error()))
	}
	s.listEdits++
	if s.needsCache != nil {
		p := s.editProblemsLocked()
		go s.send("list-problems", p)
	}
	return t, nil
}

// Undo and Redo step the workspace (u, ctrl+r).
func (s *API) Undo() (string, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.text(view.UndoRedo(s.a, false))
}

// Redo steps the workspace forward.
func (s *API) Redo() (string, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.text(view.UndoRedo(s.a, true))
}

// StageAll is T: every enabled mod but Core and the DLCs goes to staging (one undo step).
func (s *API) StageAll() (*view.Result, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.after(view.StageAll(s.a))
}

// RestoreAll puts everything in staging back (the palette).
func (s *API) RestoreAll() (string, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.text(view.RestoreAll(s.a))
}

// Swap is x.
func (s *API) Swap(id string) (string, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	st := s.boardState()
	if st == nil {
		return "", errors.New("no list")
	}
	return s.text(view.Swap(s.a, st, id))
}

// Preview is the dry run of sort, save or launch (the palette's preview…; 16 §6).
func (s *API) Preview(what string) (*view.Preview, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	return view.DryRun(s.a, what)
}

// Run does sort, save or launch at once (S, w, L; 16 §6). A refusal comes back in
// Outcome.Refused with the commands that resolve it. A launch with required mods missing
// asks first (Outcome.Confirm, VM run B8); RunAnyway goes on.
func (s *API) Run(what string) (*view.Outcome, error) {
	return s.run(what, true)
}

// RunAnyway is Run after the player chose to launch with required mods missing.
func (s *API) RunAnyway(what string) (*view.Outcome, error) {
	return s.run(what, false)
}

func (s *API) run(what string, ask bool) (*view.Outcome, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.needs = nil
	s.board = nil
	switch what {
	case view.ListSort, view.ListSave, view.ListLaunch:
	default:
		return nil, fmt.Errorf(view.T("no action %s"), what)
	}
	if ask {
		return view.RunAsking(s.a, what), nil
	}
	return view.Run(s.a, what), nil
}

// RunMoving is Run after the player agreed to move the folders in the way into the lock
// library (Outcome.Moves, 09 §3).
func (s *API) RunMoving(what string) (*view.Outcome, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.needs, s.board = nil, nil
	switch what {
	case view.ListSave, view.ListLaunch:
	default:
		return nil, fmt.Errorf(view.T("no action %s"), what)
	}
	return view.RunMoving(s.a, what), nil
}

// ---- tags (16 §3.8) ----

// TagCandidates for the mods.
func (s *API) TagCandidates(ids []string) ([]view.TagCand, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	st := s.boardState()
	if st == nil {
		return nil, errors.New("no list")
	}
	var sel [][]string
	for _, id := range ids {
		if m := st.Ix.ByID[id]; m != nil {
			sel = append(sel, m.Tags)
		}
	}
	return view.TagCandidates(s.a, st.Ix.Env.ID, sel), nil
}

// SetTag adds a tag to the mods, or removes it.
func (s *API) SetTag(ids []string, tag string, remove bool) (string, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	st := s.boardState()
	if st == nil {
		return "", errors.New("no list")
	}
	o := view.ObjectOf(st, ids)
	_, err := s.a.SetTags(o.Refs, []string{tag}, remove)
	msg := view.Tf("added %s", tag)
	if remove {
		msg = view.Tf("removed %s", tag)
	}
	return s.text(view.Tf("tags of %s: %s", o.What, msg), err)
}

// ---- whole tags: Mod library's Tag manager (16 §2.9) ----

// TagList is every tag: pinned first, then by how many mods carry it.
func (s *API) TagList() ([]cmds.TagInfo, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	return cmds.TagList(s.a)
}

// TagPreview says what merging from into into (or deleting from, into "") would change.
func (s *API) TagPreview(from []string, into string) (cmds.TagEdit, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if into == "" {
		return cmds.DeleteTags(s.a, from, true)
	}
	return cmds.MergeTags(s.a, from, into, true)
}

// RenameTag renames a tag on every mod.
func (s *API) RenameTag(from, to string) (string, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	e, err := cmds.RenameTag(s.a, from, to, false)
	return s.tagDone(view.Tf("renamed tag %s to %s on %d mods", from, strings.TrimSpace(to), e.Lineages), err)
}

// MergeTags makes the tags from into on every mod.
func (s *API) MergeTags(from []string, into string) (string, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	e, err := cmds.MergeTags(s.a, from, into, false)
	return s.tagDone(view.Tf("merged %s into %s", strings.Join(e.From, ", "), e.Into), err)
}

// DeleteTags removes the tags from every mod.
func (s *API) DeleteTags(tags []string) (string, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	e, err := cmds.DeleteTags(s.a, tags, false)
	return s.tagDone(view.Tf("removed %s from %d mods", strings.Join(e.From, ", "), e.Lineages), err)
}

// SetTagNote sets (or with "" clears) a tag's note.
func (s *API) SetTagNote(tag, note string) (string, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	t, err := cmds.SetTagNote(s.a, tag, note)
	if strings.TrimSpace(note) == "" {
		return s.tagDone(view.Tf("note of %s cleared", t), err)
	}
	return s.tagDone(view.Tf("note of %s saved", t), err)
}

// SetTagColor sets (or with "" clears) a tag's colour: a preset name or #rrggbb. It marks
// the Mods whose first tag it is (16 §2.9 Tag manager).
func (s *API) SetTagColor(tag, color string) (string, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	t, c, err := cmds.SetTagColor(s.a, tag, color)
	if c == "" {
		return s.tagDone(view.Tf("colour of %s cleared", t), err)
	}
	return s.tagDone(view.Tf("colour of %s: %s", t, view.T(c)), err)
}

// SetTagOrder puts a Mod's tags (all its copies') in this order; its first tag
// marks it in the lists.
func (s *API) SetTagOrder(id string, tags []string) (string, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	st := s.boardState()
	if st == nil || st.Ix.ByID[id] == nil {
		return "", fmt.Errorf(view.T("no mod %s"), id)
	}
	got, err := cmds.SetModTagOrder(s.a, st.Ix.Ref(id), tags)
	return s.tagDone(view.Tf("tags of %s: %s", st.Ix.ByID[id].DisplayName(), strings.Join(got, ", ")), err)
}

// PinTag pins a tag in the tag bar and the groups, or unpins it (config tags.pinned).
func (s *API) PinTag(tag string, on bool) (string, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	err := cmds.SetTagPinned(s.a, tag, on)
	if on {
		return s.tagDone(view.Tf("%s is kept on top", tag), err)
	}
	return s.tagDone(view.Tf("%s is no longer on top", tag), err)
}

// tagDone ends a whole-tag edit: tags are player data, outside the list's undo (16 §3.8).
func (s *API) tagDone(t string, err error) (string, error) {
	s.board = nil
	if err != nil {
		return "", err
	}
	return t, nil
}

// ---- Can it run (16 §5) ----

// Needs builds the screen. Opening it includes the newest log (parsing it if needed) and
// starts the files' check when it is stale, as the TUI does.
func (s *API) Needs() *view.Needs {
	s.mu.Lock()
	s.needsWanted = true
	if c, key := s.cachedNeedsLocked(); c != nil {
		if c.key == key {
			s.refreshNeedsLocked(c)
			st, _ := s.a.Loadout()
			n := view.RefreshMemory(s.a, st, c.n)
			if c.eager && n.Error == "" && (n.Stale || n.Never) && !s.busy["analyze"] {
				s.startAnalyze()
			}
			out := *n
			out.Updating = s.needsWorkLocked()
			s.mu.Unlock()
			return &out
		}
		n := *c.n
		dirs, _ := s.a.ManagedDirectories()
		db, _ := json.Marshal(dirs)
		if string(db) != c.directories {
			n = *view.RefreshDirectories(s.a, &n)
		}
		s.refreshNeedsLocked(c)
		n.Updating = s.needsWorkLocked()
		st, _ := s.a.Loadout()
		n = *view.RefreshMemory(s.a, st, &n)
		s.mu.Unlock()
		return &n
	}
	s.mu.Unlock()
	s.logRead.mu.Lock()
	defer s.logRead.mu.Unlock()
	defer s.free.soon()
	r, err := s.logSession()
	if err != nil {
		return &view.Needs{Status: map[string]int{}, Error: err.Error()}
	}
	ps, err := r.Problems(false, nil)
	if err != nil || ps == nil || ps.State == nil {
		return &view.Needs{Status: map[string]int{}, Error: fmt.Sprint(err)}
	}
	r.LazyLog, r.LogCacheOnly = false, false
	n, st := readNeeds(r, true)
	s.mu.Lock()
	defer s.mu.Unlock()
	current, _ := s.a.Loadout()
	if sameNeedsList(st, current) {
		// The eager pass may have saved a parsed log report. Read its ProblemSet again.
		ps, _ = r.Problems(false, nil)
		s.saveNeedsLocked(ps, n, true)
		if (n.Stale || n.Never) && !s.busy["analyze"] {
			s.startAnalyze()
		}
		n.Updating = s.needsWorkLocked()
	}
	return n
}

// ReadNewLog reads Player.log once when it is newer than the last launch and the last log
// read (app.NewLog): the game exited, or ran without RimArcho. Then Can it run's badge counts
// that run without a visit (16 §2.1; the sidebar's "analyse this run's log" line asked for one until
// 2026-10-30). Like opening Can it run it parses the log, records it as read and lets the
// memory go again soon; it starts no analysis. It reports whether it read one.
func (s *API) ReadNewLog() bool {
	defer perftrace.Span("ReadNewLog")()
	s.logRead.mu.Lock()
	defer s.logRead.mu.Unlock()
	defer s.free.soon()
	r, err := s.logSession()
	if err == nil {
		err = s.refreshPageIndex(r)
	}
	if err != nil {
		return false
	}
	st, err := r.Loadout()
	if err != nil || st == nil {
		return false
	}
	if _, newer := r.NewLog(st); !newer {
		return false
	}
	_, _, err = readNeedsChecked(r, true)
	return err == nil
}

// readNeeds is shared by slow page readers. The board and sidebar keep their cheap,
// cache-only path and never inherit a page's eager log parsing options.
func readNeeds(a *app.App, withLog bool) (*view.Needs, *app.LoadoutState) {
	n, st, _ := readNeedsChecked(a, withLog)
	return n, st
}

func readNeedsChecked(a *app.App, withLog bool) (*view.Needs, *app.LoadoutState, error) {
	defer perftrace.Span("Needs-read")()
	if withLog {
		a.LazyLog, a.LogCacheOnly = false, false
	}
	ps, err := a.Problems(false, nil)
	if err != nil {
		return &view.Needs{Status: map[string]int{}}, nil, err
	}
	if ps.State == nil {
		return &view.Needs{Status: map[string]int{}}, nil, errors.New(view.T("could not read list problems"))
	}
	st := ps.State
	if withLog {
		if cur, _ := a.LogPaths(st); cur != "" && a.ProblemLog(st) == cur {
			a.SelectLog(st, cur)
		}
	}
	return view.BuildNeeds(a, st, ps), st, nil
}

func (s *API) needsLocked() *view.Needs {
	if c, key := s.cachedNeedsLocked(); c != nil && c.key == key {
		s.needs = c.n
		return c.n
	}
	ps, err := s.a.Problems(false, nil)
	if err != nil {
		return &view.Needs{Status: map[string]int{}, Error: err.Error()}
	}
	if ps == nil || ps.State == nil {
		return &view.Needs{Status: map[string]int{}, Error: "could not read list problems"}
	}
	n := view.BuildNeeds(s.a, ps.State, ps)
	s.saveNeedsLocked(ps, n, false)
	return n
}

// DoAction runs an item's data action (view.Do); option picks a choose-disable choice.
func (s *API) DoAction(act view.Action, option int) (string, error) {
	if act.Kind == view.ActSubscribe {
		return s.Subscribe(SubscriptionRequest{Kind: "workshop", URL: strings.Join(act.Refs, " "), Batch: true})
	}
	if act.Kind == view.ActOpenURL {
		if err := s.open(act.URL); err != nil {
			return "", err
		}
		return act.Done, nil
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	done, err := view.Do(s.a, act, option)
	if errors.Is(err, view.ErrNothing) {
		return done, nil
	}
	return s.text(done, err)
}

// ProblemDetail opens the cached decision view before an optional provider search.
func (s *API) ProblemDetail(ref string) (*view.ProblemPanel, error) {
	// The log reader is independent of editing/navigation and reuses attributed logs.
	s.logRead.mu.Lock()
	defer s.logRead.mu.Unlock()
	defer s.free.soon()
	r, err := s.logSession()
	if err != nil {
		return nil, err
	}
	r.LazyLog, r.LogCacheOnly = false, false
	ps, err := r.Problems(false, nil)
	if err != nil {
		return nil, err
	}
	return view.BuildProblemPanel(r, ps, ref)
}

// inspectable are the read-only commands an item's "see what" may run.
var inspectable = map[string]bool{"problems": true, "patches": true, "mod": true, "def": true, "harmony": true}

// IdentityWhy is a read-only comparison requested by the player.
func (s *API) IdentityWhy(qid int64) (*view.IdentityPanel, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	return view.IdentityQuestionPanel(s.a, qid)
}

// Inspect runs a read-only command an action names (view, 16 §5) and returns its text
// with names for #refs.
func (s *API) Inspect(argv []string) ([]string, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if len(argv) == 3 && argv[0] == "identity" && argv[1] == "why" {
		qid, err := app.ParseQuestionRef(argv[2])
		if err != nil {
			return nil, err
		}
		return view.IdentityReasons(s.a, qid)
	}
	// an outside change's "see the difference" (loadout diff [<v>] [<v>]), in the window's words
	if len(argv) >= 2 && len(argv) <= 4 && argv[0] == "loadout" && argv[1] == "diff" {
		from, to := "", ""
		if len(argv) > 2 {
			from = argv[2]
		}
		if len(argv) > 3 {
			to = argv[3]
		}
		return view.VersionDiff(s.a, from, to)
	}
	directoryCheck := len(argv) == 2 && argv[0] == "folder" && argv[1] == "check"
	if len(argv) == 0 || (!directoryCheck && !inspectable[argv[0]]) {
		return nil, fmt.Errorf(view.T("not a read-only command: %v"), argv)
	}
	text, _ := cmds.Execute(s.a, argv)
	st := s.boardState()
	var out []string
	for _, l := range strings.Split(strings.TrimRight(text, "\n"), "\n") {
		out = append(out, view.Humanize(st, l))
	}
	return out, nil
}

// ---- changes (16 §2.9) ----

// Changes is the Updates page: the current plan's mods since it was last played, or the whole
// library; of (an instance ID) narrows it to that mod's Lineage, every change by day.
func (s *API) Changes(library bool, of string) (*modchanges.Page, error) {
	r, err := s.detachedReader()
	if err != nil {
		return nil, err
	}
	defer r.Close()
	defer s.free.soon()
	st, _ := r.Loadout()
	if st == nil {
		return nil, errors.New("no list")
	}
	o := modchanges.Opts{Library: library}
	if of != "" {
		o.Of = view.LineageIDs(st.Ix, of)
		if len(o.Of) == 0 {
			return nil, errors.New(view.T("that mod is not known"))
		}
		o.OfName = st.Ix.ByID[of].DisplayName()
	}
	return view.BuildChanges(r, st, o)
}

// ChangeFiles is the raw file list behind a row: the files that differ between two
// snapshots.
func (s *API) ChangeFiles(before, after int64) []string {
	s.mu.Lock()
	defer s.mu.Unlock()
	return view.ChangeFiles(s.a, before, after)
}

// OpenChangeNotes opens a Workshop item's change notes (ctrl+w on Updates).
func (s *API) OpenChangeNotes(ws string) (string, error) {
	if !view.IsNumber(ws) {
		return "", errors.New(view.T("no Workshop ID: not a Workshop mod"))
	}
	if err := s.open(view.ChangeNotesURL(ws)); err != nil {
		return "", err
	}
	return view.T("opened the change notes"), nil
}

// ---- environments, logs, scans ----

// EnvRemoval is the dry run of removing an environment (16 §2.14): the confirmation's
// title and lines. Nothing changes.
type EnvRemoval struct {
	Title string   `json:"title"`
	Lines []string `json:"lines"`
}

func (s *API) EnvRemovePreview(name string) (*EnvRemoval, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	r, err := s.a.EnvRemovePreview(name)
	if err != nil {
		return nil, err
	}
	return &EnvRemoval{Title: view.EnvRemovalTitle(r), Lines: view.EnvRemovalLines(r)}, nil
}

// RemoveEnv removes an environment from RimArcho's records; another one becomes current
// when it was in use. Refused while its game runs.
func (s *API) RemoveEnv(name string) (string, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.a.EnvName = ""
	_, err := s.a.EnvRemove(name)
	s.board, s.needs, s.lib = nil, nil, nil
	return s.text(view.Tf("removed game %s", name), err)
}

// Logs are the logs the player may choose (Player.log, Player-prev.log).
func (s *API) Logs() []string {
	s.mu.Lock()
	defer s.mu.Unlock()
	st := s.boardState()
	if st == nil {
		return nil
	}
	var out []string
	cur, prev := s.a.LogPaths(st)
	for _, p := range []string{cur, prev} {
		if p != "" {
			out = append(out, p)
		}
	}
	return out
}

// LogPage analyses a log for the Game log tab (the newest when path is empty).
func (s *API) LogPage(path string) (*view.LogPage, error) {
	// Serialise log reads with each other, not with the board, navigation or textures.
	// Keeping this reader also preserves pending cross-version analysis between polls.
	s.logRead.mu.Lock()
	defer s.logRead.mu.Unlock()
	defer s.free.soon()
	r, err := s.logSession()
	if err != nil {
		return nil, err
	}
	readState, err := r.Loadout()
	if err != nil {
		return nil, err
	}
	p, err := view.BuildLogPage(r, readState, path, nil)
	s.mu.Lock()
	defer s.mu.Unlock()
	if err == nil && p.Path != "" {
		if current := s.boardState(); current != nil && current.Ix.Env.ID == readState.Ix.Env.ID {
			s.logLinks, s.logPath = p.Links, p.Path
			if m := view.LiveMonitor(s.a, current, &s.live, p.Path, p.Links); m != nil {
				p.Monitor, p.NoMonitor, p.AddMonitor = m, "", false
			}
		}
	}
	return p, err
}

// LogMonitor is the companion section of path as the running game writes it, for the log
// page's refresh on the live tick (nil when the game does not write path).
func (s *API) LogMonitor(path string) (*view.MonitorLog, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	st := s.boardState()
	if st == nil {
		return nil, errors.New("no list")
	}
	var links map[string]string
	if strings.EqualFold(s.logPath, path) {
		links = s.logLinks
	}
	return view.LiveMonitor(s.a, st, &s.live, path, links), nil
}

// AddMonitor puts Archo Monitor after Harmony in the current plan (the log page's action;
// one undoable step).
func (s *API) AddMonitor() (string, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.text(view.MonitorAdd(s.a))
}

// LogCluster is one cluster's evidence (archo log --cluster), names for #refs.
func (s *API) LogCluster(path, id string) ([]string, error) {
	if path == "" || id == "" || strings.HasPrefix(path, "-") || strings.HasPrefix(id, "-") {
		return nil, errors.New("no cluster")
	}
	s.logRead.mu.Lock()
	defer s.logRead.mu.Unlock()
	defer s.free.soon()
	r, err := s.logSession()
	if err != nil {
		return nil, err
	}
	st, err := r.Loadout()
	if err != nil {
		return nil, err
	}
	text, _ := cmds.Execute(r, []string{"log", "--file", path, "--cluster", id})
	var out []string
	for _, l := range view.WithoutPatternBlock(strings.Split(strings.TrimRight(text, "\n"), "\n")) {
		out = append(out, view.Humanize(st, l))
	}
	return out, nil
}

// LogPattern is the pattern card of a cluster (16 §2.10): community background shown apart
// from the evidence; nil when the cluster matches no pattern.
func (s *API) LogPattern(path, id string) *view.PatternCard {
	s.logRead.mu.Lock()
	defer s.logRead.mu.Unlock()
	defer s.free.soon()
	r, err := s.logSession()
	if err != nil {
		return nil
	}
	st, err := r.Loadout()
	if err != nil {
		return nil
	}
	return view.PatternCardOf(r, st, path, id)
}

// SelectLog picks the log whose errors join Can it run.
func (s *API) SelectLog(path string) (string, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	st := s.boardState()
	if st == nil {
		return "", errors.New("no list")
	}
	s.needs = nil
	return s.text(view.T("the log is read"), s.a.SelectLog(st, path))
}

// Scan rescans in a child process; the "scan" event says when it is done.
func (s *API) Scan() bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.busy["scan"] {
		return false
	}
	s.busy["scan"] = true
	home, env := s.a.Home, s.a.EnvName
	task := s.beginSelf(view.TaskScan, env, nil)
	go func() {
		s.filesMu.Lock()
		var out string
		var err error
		exe := s.Exe
		if exe == "" {
			exe, _ = os.Executable()
		}
		var meter scanMeter
		out, err = app.ChildScanProgress(exe, home, env, func(p app.ScanProgress) {
			if frac, text := meter.step(p, env); text != "" {
				s.tasks.Update(task, func(t *app.Task) { t.Phase, t.Frac = text, frac })
			}
		})
		s.filesMu.Unlock()
		s.mu.Lock()
		s.busy["scan"], s.board, s.needs = false, nil, nil
		s.mu.Unlock()
		ev := map[string]any{"ok": err == nil}
		if err != nil {
			reason := view.Humanize(nil, firstLine(out)+" "+err.Error())
			ev["error"] = failedText(view.TaskScan, env, reason)
			s.endSelf(task, errors.New(reason), "")
		} else {
			ev["text"] = view.T("scan complete")
			s.endSelf(task, nil, ev["text"].(string))
		}
		s.free.soon()
		s.send("scan", ev)
	}()
	return true
}

// Analyze checks the mods' files again in a child process; "analyze" events carry the
// progress lines and the end.
func (s *API) Analyze() bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.startAnalyze()
}

func (s *API) startAnalyze() bool { return s.startAnalyzeOf("") }

// startAnalyzeOf analyses a list by name ("" the open one); s.mu is held.
func (s *API) startAnalyzeOf(list string) bool {
	if s.needsClosed || s.busy["analyze"] {
		return false
	}
	s.busy["analyze"] = true
	run := s.a.AnalyzeRunner
	home, env, exe, plan := s.a.Home, s.a.EnvName, s.Exe, s.a.OpenPlanName()
	mm := s.a.GameVersion
	scope, _, _, _ := s.needsKeyLocked()
	obj := env
	if s.board != nil && s.board.St != nil && s.board.St.Plan != nil {
		obj = s.board.St.Plan.Name
	}
	if list != "" {
		plan, obj = list, list
	}
	task := s.beginSelf(view.TaskAnalyze, obj, nil)
	// the open list's findings will change: its problems button says so while this runs
	if c, _ := s.cachedNeedsLocked(); c != nil && c.scope == scope {
		ev := s.problemsNowLocked(c.n)
		go s.send("list-problems", ev)
	}
	s.needsJobs.Add(1)
	go func() {
		defer s.needsJobs.Done()
		progress := func(l string) {
			l = view.AnalyzeProgress(strings.TrimPrefix(l, "progress: "))
			s.tasks.Update(task, func(t *app.Task) { t.Phase = l })
			s.send("analyze", map[string]any{"line": l})
		}
		var err error
		switch {
		case run != nil:
			err = run(env, progress)
		case exe != "":
			err = app.ChildAnalyzeExe(exe, home, env, plan, mm, progress)
		default:
			err = app.ChildAnalyze(home, env, plan, mm, progress)
		}
		s.mu.Lock()
		s.busy["analyze"], s.needs = false, nil
		if err != nil {
			if c, _ := s.cachedNeedsLocked(); c != nil && c.scope == scope {
				n := *c.n
				s.needsSequence++
				n.Sequence = s.needsSequence
				n.Updating = false
				n.Error = err.Error()
				c.n = &n
				go s.send("list-problems", view.ProblemsOf(&n))
			}
		}
		if err == nil {
			if c, _ := s.cachedNeedsLocked(); c != nil {
				s.refreshNeedsLocked(c)
			}
		}
		s.mu.Unlock()
		s.endSelf(task, err, view.T("analysis done"))
		ev := map[string]any{"done": true, "ok": err == nil}
		if err != nil {
			ev["error"] = failedText(view.TaskAnalyze, obj, err.Error())
		}
		s.send("analyze", ev)
	}()
	return true
}

// ---- palette and the rest ----

// Palette ranks commands, mods and the other environments for a query (16 §3.5).
func (s *API) Palette(query string) []view.PalEntry {
	s.mu.Lock()
	defer s.mu.Unlock()
	all := view.CommandEntries()
	cur := ""
	if s.board != nil {
		cur = s.board.EnvName
	}
	if envs, err := s.a.Store.Envs(); err == nil {
		for _, e := range envs {
			if e.Name != cur {
				all = append(all, view.PalEntry{Kind: view.PalEnv, ID: e.Name, Name: view.Tf("switch to %s", e.Name), Alias: e.Name, Desc: "env"})
			}
		}
	}
	if rows, err := view.PlanRows(s.a); err == nil {
		all = append(all, view.PlanEntries(rows)...)
	}
	if s.board != nil {
		seen := map[string]bool{}
		for _, col := range s.board.Cols {
			for _, it := range col {
				if it.ID == "" || seen[it.ID] {
					continue
				}
				seen[it.ID] = true
				all = append(all, view.PalEntry{Kind: view.PalMod, ID: it.ID, Name: it.Name, Desc: it.Package + " " + it.Author})
			}
		}
	}
	out := view.PalRank(query, all)
	if len(out) > 50 {
		out = out[:50]
	}
	return out
}

// OpenURL opens an http(s) link in the system browser (links in descriptions, the
// Workshop page).
func (s *API) OpenURL(raw string) error {
	u, err := url.Parse(raw)
	if err != nil || (u.Scheme != "http" && u.Scheme != "https") || u.Host == "" {
		return fmt.Errorf(view.T("not a web link: %s"), raw)
	}
	return s.open(u.String())
}

// SaveRefNums writes a page's reference numbers (ctrl+\, refnums.js) to
// refnums/<prefix>.txt in the data directory, one line per number with where it sits in
// the page and its text, so "change hom22" can be looked up without opening the window.
func (s *API) SaveRefNums(prefix, text string) error {
	for _, c := range prefix {
		if c < 'a' || c > 'z' {
			return fmt.Errorf(view.T("not a page prefix: %q"), prefix)
		}
	}
	if prefix == "" || len(prefix) > 8 {
		return fmt.Errorf(view.T("not a page prefix: %q"), prefix)
	}
	dir := filepath.Join(s.a.Home, "refnums")
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return err
	}
	p := filepath.Join(dir, prefix+".txt")
	if err := os.WriteFile(p+".tmp", []byte(text), 0o644); err != nil {
		return err
	}
	return os.Rename(p+".tmp", p)
}

// Setting reads a GUI setting (column widths, 16 §7).
func (s *API) Setting(key string) string {
	defer perftrace.Span("Setting")()
	s.mu.Lock()
	defer s.mu.Unlock()
	if !strings.HasPrefix(key, "ui.gui.") {
		return ""
	}
	return s.a.Store.Meta(key)
}

// SetSetting stores a GUI setting.
func (s *API) SetSetting(key, value string) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	if !strings.HasPrefix(key, "ui.gui.") {
		return fmt.Errorf(view.T("not a GUI setting: %s"), key)
	}
	return s.a.Store.SetMeta(key, value)
}

func firstLine(s string) string {
	s = strings.TrimSpace(s)
	if i := strings.IndexByte(s, '\n'); i >= 0 {
		return s[:i]
	}
	return s
}
