package view

import "github.com/ToumanLin/RimArcho/internal/l10ndata"

type localeTable = l10ndata.LocaleTable

var locales = l10ndata.Locales

func localeExtra(lang, key string) string { return l10ndata.Extra(lang, key) }

func languageChoices() []string {
	choices := []string{"auto", "ja", "en", "zh"}
	for _, code := range l10ndata.LanguageCodes() {
		if code != "auto" && code != "ja" && code != "zh" && code != "en" {
			choices = append(choices, code)
		}
	}
	return choices
}

func languageLabels() []string {
	labels := []string{T("follow system"), l10ndata.JapaneseLanguageName, "English", l10ndata.ChineseLanguageName}
	labels = append(labels, languageChoices()[4:]...)
	return labels
}
