# Suggested GitHub pull request / issue message

**Title:** Add Japanese (ja) localization for RimArcho

Hello! I prepared a community Japanese translation for RimArcho, based on the v1.0.9 source snapshot.

This contribution adds Japanese as a selectable interface language (including `ja-JP` automatic detection), provides translated GUI/settings/diagnostic strings, and adds Japanese strings for the Archo Monitor companion mod. It includes 3,762 standard translation keys, 81 auxiliary keys, and localization regression tests.

I tested earlier Japanese GUI preview builds on Windows and confirmed that the language option and main screens worked. The final consolidated source patch has passed locale-related validation, but I have **not yet completed a full Windows GUI regression test or in-game Archo Monitor test for this exact patch**.

Mod titles, external Workshop descriptions, raw game logs, and some CLI help text are intentionally left unchanged. Remaining dynamic strings may fall back to English.

The attached ZIP provides a `git apply` patch, an equivalent file overlay, and integration notes. The MIT license and original upstream copyright notice are retained.

I would be happy if you considered incorporating the Japanese language option into the official project. Thank you for developing RimArcho!

*Japanese localization contributor: [your preferred name or GitHub handle]*  
*Translation drafting assistance: ChatGPT (OpenAI)*
