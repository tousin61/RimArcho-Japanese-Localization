# RimArcho — Japanese localization contribution

This package proposes a **Japanese (`ja`) interface locale** for the RimArcho source snapshot shipped as `RimArcho-master.zip` (v1.0.9, dated 2026-11-10 in the included changelog). It is an **unofficial, community-prepared contribution**, not an official release or a replacement application.

## What changes

- Adds **3,762 unique standard translations** plus **81 auxiliary translations**, organized by feature into JSON files under `internal/l10ndata/locale/ja/`.
- Adds `ja` to the language selection list; supports `ja-JP` and other `ja*` system-language values through `ResolveLang`, and keeps English/Chinese available.
- Localizes a small set of error messages emitted directly by GUI backend methods and the common JavaScript error display.
- Adds Japanese Archo Monitor in-game settings at `monitor/Languages/Japanese/Keyed/Settings.xml` (source folder used by `monitor/build.ps1`).
- Adds Go regression tests for locale selection, representative translations, parity with existing Chinese translation keys, duplicate key detection, and diagnostic format examples.

**Intentionally not localized:** mod names, author names, Steam Workshop descriptions, raw logs and stack traces, and many CLI `--help` messages. Dynamic/unregistered text may still fall back to English.

## Applying the patch

With a clean checkout matching the supplied upstream snapshot, run:

```sh
git apply --check japanese-localization.patch
git apply japanese-localization.patch
go test ./internal/l10ndata
```

Alternatively, copy the contents of `changes/` into the root of the project, preserving folder paths. Do **not** copy the `changes` folder itself as a nested directory.

The `changes/` tree and `japanese-localization.patch` contain the **same changes**; apply **only one** of them. After integration, the maintainer can build the GUI and Archo Monitor using the project's existing build/release procedure.

## What is not included

No executable, Go dependencies, compiled DLL, SDK, test fixture binaries, generated mod folder, installer, or local Windows build wrapper is included. There are no changes to `go.mod`, `go.sum`, or unrelated product features. All code changes remain in existing localization or GUI error-display paths.

## Validation and limitations

See `VALIDATION.md` for checks and outstanding work. The localization was visually confirmed on Windows in earlier preview builds by the contributor; this **consolidated submission package** still needs a full upstream Windows GUI regression test and an in-game Archo Monitor test. The user has not yet reported a v6 Windows run.

The JSON files here consolidate the earlier preview's version-numbered translation files into maintainable feature groups. The combined keys/values are unchanged from the v6 source supplied for this contribution; this is a packaging change, not a new translation review.

## Attribution and license

RimArcho is copyright (c) 2026 Touman Lin, under the MIT License; the original license text is included. This contribution was prepared with ChatGPT (OpenAI) assistance, with on-screen review by a Japanese-speaking user. The contributor may provide their preferred GitHub attribution separately.
